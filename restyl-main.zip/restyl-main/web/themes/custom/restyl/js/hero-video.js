(function () {
  const theme = document.querySelector('[data-restyl-theme-path]');
  const layer = document.querySelector('.rev_slider_wrapper .rs-background-video-layer');
  if (!theme || !layer) {
    return;
  }

  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const updateVideo = () => {
    const existing = layer.querySelector('video');
    if (reducedMotion.matches) {
      if (existing) {
        existing.pause();
        existing.remove();
      }
      layer.querySelector('.hero-video-toggle')?.remove();
      return;
    }
    if (existing) {
      return;
    }

    const video = document.createElement('video');
    video.autoplay = true;
    video.muted = true;
    video.loop = true;
    video.playsInline = true;
    video.preload = 'metadata';
    video.setAttribute('aria-hidden', 'true');
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'hero-video-toggle';
    button.textContent = 'Přehrát video';
    video.addEventListener('playing', () => {
      video.classList.add('is-playing');
      button.textContent = 'Pozastavit video';
    });
    video.addEventListener('pause', () => {
      button.textContent = 'Přehrát video';
    });
    ['webm', 'mp4'].forEach((format) => {
      const source = document.createElement('source');
      source.src = `${theme.dataset.restylThemePath}/images/home-hero.${format}`;
      source.type = `video/${format}`;
      if (format === 'mp4') {
        source.addEventListener('error', () => {
          console.warn('RESTYL: Úvodní video nelze načíst; zobrazuje se náhradní obrázek.');
          button.remove();
        });
      }
      video.appendChild(source);
    });
    video.addEventListener('error', () => {
      console.warn('RESTYL: Úvodní video nelze načíst; zobrazuje se náhradní obrázek.');
      button.remove();
    });
    button.addEventListener('click', () => {
      if (video.paused) {
        video.play().catch((error) => {
          console.warn('RESTYL: Úvodní video nelze přehrát.', error);
        });
      } else {
        video.pause();
      }
    });
    layer.appendChild(video);
    layer.appendChild(button);
  };

  updateVideo();
  reducedMotion.addEventListener('change', updateVideo);
})();
